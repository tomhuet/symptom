<?php
require_once '../config.php';
if (!isLoggedIn()) { header('Location: index.php'); exit; }

if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $projects = getProjects();
    $projects = array_values(array_filter($projects, function($p) {
        return $p['id'] !== $_GET['delete'];
    }));
    saveProjects($projects);
    header('Location: projects.php?deleted=1');
    exit;
}

$projects = getProjects();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Projets - SYMPTOM Admin</title>
  <link rel="stylesheet" href="admin-styles.css">
</head>
<body>
  <div class="admin-layout">
    <aside class="sidebar">
      <div class="sidebar-logo">SYMPTOM</div>
      <nav class="sidebar-nav">
        <a href="dashboard.php" class="nav-item">📊 Dashboard</a>
        <a href="projects.php" class="nav-item active">📁 Projets</a>
        <a href="reviews.php" class="nav-item">⭐ Avis</a>
        <a href="logout.php" class="nav-item nav-logout">🚪 Déconnexion</a>
      </nav>
    </aside>
    
    <main class="main-content">
      <header class="content-header">
        <h1>Projets</h1>
        <a href="project-edit.php" class="btn btn-primary">+ Nouveau projet</a>
      </header>
      
      <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success">✅ Projet supprimé avec succès.</div>
      <?php endif; ?>
      <?php if (isset($_GET['saved'])): ?>
        <div class="alert alert-success">✅ Projet enregistré avec succès.</div>
      <?php endif; ?>
      
      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr>
              <th>Entreprise</th>
              <th>Secteur</th>
              <th>Problématique</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $reversedProjects = array_reverse($projects);
            foreach ($reversedProjects as $project): 
            ?>
            <tr>
              <td><strong><?php echo htmlspecialchars($project['company']); ?></strong></td>
              <td><span class="badge"><?php echo htmlspecialchars($project['sector']); ?></span></td>
              <td class="text-truncate" title="<?php echo htmlspecialchars($project['problem']); ?>">
                <?php echo htmlspecialchars(mb_substr($project['problem'], 0, 60)) . (mb_strlen($project['problem']) > 60 ? '...' : ''); ?>
              </td>
              <td><?php echo date('d/m/Y', strtotime($project['created_at'])); ?></td>
              <td class="actions-cell">
                <a href="/projet/<?php echo htmlspecialchars($project['slug']); ?>" target="_blank" class="btn-icon" title="Voir sur le site">👁️</a>
                <a href="project-edit.php?id=<?php echo htmlspecialchars($project['id']); ?>" class="btn-icon" title="Modifier">✏️</a>
                <a href="projects.php?delete=<?php echo htmlspecialchars($project['id']); ?>" class="btn-icon btn-danger" title="Supprimer" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce projet ?')">🗑️</a>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($projects)): ?>
            <tr>
              <td colspan="5" class="empty-state">
                Aucun projet pour le moment.<br>
                <a href="project-edit.php">Créer le premier projet</a>
              </td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>
</body>
</html>