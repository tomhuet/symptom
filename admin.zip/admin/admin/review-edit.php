<?php
require_once '../config.php';
if (!isLoggedIn()) { header('Location: index.php'); exit; }

$review = null;
$isEdit = false;
$error = '';
$projects = getProjects();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $reviews = getReviews();
    foreach ($reviews as $r) {
        if ($r['id'] === $_GET['id']) {
            $review = $r;
            $isEdit = true;
            break;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $author = trim($_POST['author'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $position = trim($_POST['position'] ?? '');
    $rating = intval($_POST['rating'] ?? 5);
    $content = trim($_POST['content'] ?? '');
    $project_id = $_POST['project_id'] ?? '';
    
    if (empty($author) || empty($content)) {
        $error = 'Veuillez remplir tous les champs obligatoires.';
    } else {
        $reviews = getReviews();
        
        $newReview = [
            'id' => $isEdit ? $review['id'] : generateId(),
            'author' => $author,
            'company' => $company,
            'position' => $position,
            'rating' => max(1, min(5, $rating)),
            'content' => $content,
            'project_id' => !empty($project_id) ? $project_id : null,
            'created_at' => $isEdit ? $review['created_at'] : date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        if ($isEdit) {
            foreach ($reviews as $key => $r) {
                if ($r['id'] === $review['id']) {
                    $reviews[$key] = $newReview;
                    break;
                }
            }
        } else {
            $reviews[] = $newReview;
        }
        
        saveReviews($reviews);
        header('Location: reviews.php?saved=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $isEdit ? 'Modifier' : 'Nouvel'; ?> avis - SYMPTOM Admin</title>
  <link rel="stylesheet" href="admin-styles.css">
</head>
<body>
  <div class="admin-layout">
    <aside class="sidebar">
      <div class="sidebar-logo">SYMPTOM</div>
      <nav class="sidebar-nav">
        <a href="dashboard.php" class="nav-item">📊 Dashboard</a>
        <a href="projects.php" class="nav-item">📁 Projets</a>
        <a href="reviews.php" class="nav-item active">⭐ Avis</a>
        <a href="logout.php" class="nav-item nav-logout">🚪 Déconnexion</a>
      </nav>
    </aside>
    
    <main class="main-content">
      <header class="content-header">
        <div class="header-left">
          <a href="reviews.php" class="btn-back">← Retour</a>
          <h1><?php echo $isEdit ? 'Modifier l\'avis' : 'Nouvel avis'; ?></h1>
        </div>
      </header>
      
      <?php if ($error): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
      <?php endif; ?>
      
      <form method="POST" class="edit-form">
        <div class="form-row">
          <div class="form-group">
            <label for="author">Nom de l'auteur <span class="required">*</span></label>
            <input type="text" id="author" name="author" value="<?php echo htmlspecialchars($review['author'] ?? $_POST['author'] ?? ''); ?>" required placeholder="Jean Dupont">
          </div>
          <div class="form-group">
            <label for="company">Entreprise</label>
            <input type="text" id="company" name="company" value="<?php echo htmlspecialchars($review['company'] ?? $_POST['company'] ?? ''); ?>" placeholder="Nom de l'entreprise">
          </div>
        </div>
        
        <div class="form-row">
          <div class="form-group">
            <label for="position">Poste / Fonction</label>
            <input type="text" id="position" name="position" value="<?php echo htmlspecialchars($review['position'] ?? $_POST['position'] ?? ''); ?>" placeholder="Directeur Marketing">
          </div>
          <div class="form-group">
            <label for="rating">Note <span class="required">*</span></label>
            <div class="rating-input">
              <?php 
              $currentRating = $review['rating'] ?? $_POST['rating'] ?? 5;
              for ($i = 5; $i >= 1; $i--): 
              ?>
                <input type="radio" id="rating<?php echo $i; ?>" name="rating" value="<?php echo $i; ?>" <?php echo $currentRating == $i ? 'checked' : ''; ?>>
                <label for="rating<?php echo $i; ?>" title="<?php echo $i; ?> étoile<?php echo $i > 1 ? 's' : ''; ?>">★</label>
              <?php endfor; ?>
            </div>
          </div>
        </div>
        
        <div class="form-group">
          <label for="project_id">Lier à un projet (optionnel)</label>
          <select id="project_id" name="project_id">
            <option value="">-- Aucun projet lié --</option>
            <?php foreach ($projects as $p): ?>
              <option value="<?php echo htmlspecialchars($p['id']); ?>" <?php echo (isset($review['project_id']) && $review['project_id'] === $p['id']) || (isset($_POST['project_id']) && $_POST['project_id'] === $p['id']) ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($p['company']); ?> (<?php echo htmlspecialchars($p['sector']); ?>)
              </option>
            <?php endforeach; ?>
          </select>
          <small class="form-help">Lier cet avis à un projet existant permet de l'afficher sur la page du projet.</small>
        </div>
        
        <div class="form-group">
          <label for="content">Contenu de l'avis <span class="required">*</span></label>
          <textarea id="content" name="content" rows="6" required placeholder="Témoignage du client..."><?php echo htmlspecialchars($review['content'] ?? $_POST['content'] ?? ''); ?></textarea>
        </div>
        
        <div class="form-actions">
          <a href="reviews.php" class="btn btn-outline">Annuler</a>
          <button type="submit" class="btn btn-primary">
            <?php echo $isEdit ? '💾 Enregistrer les modifications' : '✅ Créer l\'avis'; ?>
          </button>
        </div>
      </form>
    </main>
  </div>
</body>
</html>