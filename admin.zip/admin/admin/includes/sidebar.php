<aside class="sidebar">
  <div class="sidebar-logo">SYMPTOM</div>
  <nav class="sidebar-nav">
    <a href="dashboard.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>">📊 Dashboard</a>
    <a href="projects.php" class="nav-item <?php echo in_array(basename($_SERVER['PHP_SELF']), ['projects.php', 'project-edit.php']) ? 'active' : ''; ?>">📁 Projets</a>
    <a href="reviews.php" class="nav-item <?php echo in_array(basename($_SERVER['PHP_SELF']), ['reviews.php', 'review-edit.php']) ? 'active' : ''; ?>">⭐ Avis</a>
    <a href="logout.php" class="nav-item nav-logout">🚪 Déconnexion</a>
  </nav>
</aside>