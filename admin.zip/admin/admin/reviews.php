<?php
require_once '../config.php';
if (!isLoggedIn()) { header('Location: index.php'); exit; }

if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $reviews = getReviews();
    $reviews = array_values(array_filter($reviews, function($r) {
        return $r['id'] !== $_GET['delete'];
    }));
    saveReviews($reviews);
    header('Location: reviews.php?deleted=1');
    exit;
}

$reviews = getReviews();
$projects = getProjects();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Avis - SYMPTOM Admin</title>
  <link rel="stylesheet" href="admin-styles.css">
</head>
<body>
  <div class="admin-layout">
    <aside class="sidebar">
      <div class="sidebar-logo">SYMPTOM</div>
      <nav class="sidebar-nav">
        <a href="dashboard.php" class="nav-item">📊 Dashboard</a>
        <a href="projects.php" class="nav-item">📁 Projets</a>
        <a href="reviews.php" class="nav-item active">⭐ Avis</a>
        <a href="logout.php" class="nav-item nav-logout">🚪 Déconnexion</a>
      </nav>
    </aside>
    
    <main class="main-content">
      <header class="content-header">
        <h1>Avis clients</h1>
        <a href="review-edit.php" class="btn btn-primary">+ Nouvel avis</a>
      </header>
      
      <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success">✅ Avis supprimé avec succès.</div>
      <?php endif; ?>
      <?php if (isset($_GET['saved'])): ?>
        <div class="alert alert-success">✅ Avis enregistré avec succès.</div>
      <?php endif; ?>
      
      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr>
              <th>Auteur</th>
              <th>Entreprise</th>
              <th>Note</th>
              <th>Projet lié</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $reversedReviews = array_reverse($reviews);
            foreach ($reversedReviews as $review): 
              $linkedProject = null;
              if (!empty($review['project_id'])) {
                  foreach ($projects as $p) {
                      if ($p['id'] === $review['project_id']) {
                          $linkedProject = $p;
                          break;
                      }
                  }
              }
            ?>
            <tr>
              <td><strong><?php echo htmlspecialchars($review['author']); ?></strong></td>
              <td><?php echo !empty($review['company']) ? htmlspecialchars($review['company']) : '<span class="text-muted">-</span>'; ?></td>
              <td>
                <div class="stars-display">
                  <?php for ($i = 1; $i <= 5; $i++): ?>
                    <span class="star <?php echo $i <= $review['rating'] ? 'filled' : ''; ?>">★</span>
                  <?php endfor; ?>
                </div>
              </td>
              <td>
                <?php if ($linkedProject): ?>
                  <span class="badge"><?php echo htmlspecialchars($linkedProject['company']); ?></span>
                <?php else: ?>
                  <span class="text-muted">Aucun</span>
                <?php endif; ?>
              </td>
              <td><?php echo date('d/m/Y', strtotime($review['created_at'])); ?></td>
              <td class="actions-cell">
                <a href="review-edit.php?id=<?php echo htmlspecialchars($review['id']); ?>" class="btn-icon" title="Modifier">✏️</a>
                <a href="reviews.php?delete=<?php echo htmlspecialchars($review['id']); ?>" class="btn-icon btn-danger" title="Supprimer" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet avis ?')">🗑️</a>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($reviews)): ?>
            <tr>
              <td colspan="6" class="empty-state">
                Aucun avis pour le moment.<br>
                <a href="review-edit.php">Créer le premier avis</a>
              </td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>
</body>
</html>