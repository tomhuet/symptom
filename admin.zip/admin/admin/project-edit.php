<?php
require_once '../config.php';
if (!isLoggedIn()) { header('Location: index.php'); exit; }

$project = null;
$isEdit = false;
$error = '';
$success = '';

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $projects = getProjects();
    foreach ($projects as $p) {
        if ($p['id'] === $_GET['id']) {
            $project = $p;
            $isEdit = true;
            break;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $company = trim($_POST['company'] ?? '');
    $sector = trim($_POST['sector'] ?? '');
    $problem = trim($_POST['problem'] ?? '');
    $description = $_POST['description'] ?? '';
    $feedback = trim($_POST['feedback'] ?? '');
    
    if (empty($company) || empty($sector) || empty($problem)) {
        $error = 'Veuillez remplir tous les champs obligatoires.';
    } else {
        $projects = getProjects();
        
        // Gestion de l'image
        $imagePath = $isEdit && isset($project['image']) ? $project['image'] : '';
        if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploaded = uploadImage($_FILES['image']);
            if ($uploaded) {
                $imagePath = $uploaded;
            }
        }
        
        $newProject = [
            'id' => $isEdit ? $project['id'] : generateId(),
            'company' => $company,
            'sector' => $sector,
            'problem' => $problem,
            'description' => $description,
            'feedback' => $feedback,
            'image' => $imagePath,
            'slug' => generateSlug($company),
            'created_at' => $isEdit ? $project['created_at'] : date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        if ($isEdit) {
            foreach ($projects as $key => $p) {
                if ($p['id'] === $project['id']) {
                    $projects[$key] = $newProject;
                    break;
                }
            }
        } else {
            $projects[] = $newProject;
        }
        
        saveProjects($projects);
        header('Location: projects.php?saved=1');
        exit;
    }
}

$sectors = ['Hôtel', 'Restaurant', 'Boutique', 'E-commerce', 'Santé', 'Finance', 'Industrie', 'Services', 'Tech', 'Immobilier', 'Éducation', 'Autre'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $isEdit ? 'Modifier' : 'Nouveau'; ?> projet - SYMPTOM Admin</title>
  <link rel="stylesheet" href="admin-styles.css">
</head>
<body>
  <div class="admin-layout">
    <aside class="sidebar">
      <div class="sidebar-logo">SYMPTOM</div>
      <nav class="sidebar-nav">
        <a href="dashboard.php" class="nav-item">📊 Dashboard</a>
        <a href="projects.php" class="nav-item active">📁 Projets</a>
        <a href="reviews.php" class="nav-item">⭐ Avis</a>
        <a href="logout.php" class="nav-item nav-logout">🚪 Déconnexion</a>
      </nav>
    </aside>
    
    <main class="main-content">
      <header class="content-header">
        <div class="header-left">
          <a href="projects.php" class="btn-back">← Retour</a>
          <h1><?php echo $isEdit ? 'Modifier le projet' : 'Nouveau projet'; ?></h1>
        </div>
      </header>
      
      <?php if ($error): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
      <?php endif; ?>
      
      <form method="POST" enctype="multipart/form-data" class="edit-form">
        <div class="form-row">
          <div class="form-group">
            <label for="company">Nom de l'entreprise <span class="required">*</span></label>
            <input type="text" id="company" name="company" value="<?php echo htmlspecialchars($project['company'] ?? $_POST['company'] ?? ''); ?>" required>
          </div>
          <div class="form-group">
            <label for="sector">Secteur <span class="required">*</span></label>
            <select id="sector" name="sector" required>
              <option value="">Sélectionner un secteur...</option>
              <?php foreach ($sectors as $s): ?>
                <option value="<?php echo htmlspecialchars($s); ?>" <?php echo (isset($project['sector']) && $project['sector'] === $s) || (isset($_POST['sector']) && $_POST['sector'] === $s) ? 'selected' : ''; ?>><?php echo htmlspecialchars($s); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        
        <div class="form-group">
          <label for="image">Image du projet</label>
          <?php if ($isEdit && !empty($project['image'])): ?>
            <div class="current-image">
              <img src="/<?php echo htmlspecialchars($project['image']); ?>" alt="Image actuelle">
              <span>Image actuelle</span>
            </div>
          <?php endif; ?>
          <input type="file" id="image" name="image" accept="image/jpeg,image/png,image/webp">
          <small class="form-help">Formats acceptés : JPG, PNG, WebP. Taille recommandée : 1200x800px minimum.</small>
        </div>
        
        <div class="form-group">
          <label for="problem">Problématique <span class="required">*</span></label>
          <textarea id="problem" name="problem" rows="3" required placeholder="Décrivez la problématique principale du client..."><?php echo htmlspecialchars($project['problem'] ?? $_POST['problem'] ?? ''); ?></textarea>
        </div>
        
        <div class="form-group">
          <label for="description">Description détaillée</label>
          <div class="editor-toolbar">
            <button type="button" onclick="insertTag('strong')" title="Gras"><strong>B</strong></button>
            <button type="button" onclick="insertTag('em')" title="Italique"><em>I</em></button>
            <button type="button" onclick="insertTag('h3')" title="Titre">H3</button>
            <button type="button" onclick="insertTag('p')" title="Paragraphe">P</button>
            <button type="button" onclick="insertList()" title="Liste">• Liste</button>
          </div>
          <textarea id="description" name="description" rows="12" placeholder="Décrivez le projet en détail. Vous pouvez utiliser du HTML..."><?php echo htmlspecialchars($project['description'] ?? $_POST['description'] ?? ''); ?></textarea>
          <small class="form-help">HTML autorisé : &lt;p&gt;, &lt;h3&gt;, &lt;ul&gt;, &lt;li&gt;, &lt;strong&gt;, &lt;em&gt;, &lt;a&gt;</small>
        </div>
        
        <div class="form-group">
          <label for="feedback">Retour de l'entreprise</label>
          <textarea id="feedback" name="feedback" rows="4" placeholder="Témoignage ou retour du client sur le projet..."><?php echo htmlspecialchars($project['feedback'] ?? $_POST['feedback'] ?? ''); ?></textarea>
        </div>
        
        <div class="form-actions">
          <a href="projects.php" class="btn btn-outline">Annuler</a>
          <button type="submit" class="btn btn-primary">
            <?php echo $isEdit ? '💾 Enregistrer les modifications' : '✅ Créer le projet'; ?>
          </button>
        </div>
      </form>
    </main>
  </div>
  
  <script>
  function insertTag(tag) {
    var textarea = document.getElementById('description');
    var start = textarea.selectionStart;
    var end = textarea.selectionEnd;
    var text = textarea.value.substring(start, end);
    var before = textarea.value.substring(0, start);
    var after = textarea.value.substring(end);
    
    textarea.value = before + '<' + tag + '>' + text + '</' + tag + '>' + after;
    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = start + tag.length + 2 + text.length;
  }
  
  function insertList() {
    var textarea = document.getElementById('description');
    var start = textarea.selectionStart;
    var before = textarea.value.substring(0, start);
    var after = textarea.value.substring(start);
    
    var list = '<ul>\n  <li></li>\n  <li></li>\n  <li></li>\n</ul>';
    textarea.value = before + list + after;
    textarea.focus();
  }
  </script>
</body>
</html>