<?php
require_once '../config.php';
if (!isLoggedIn()) { header('Location: index.php'); exit; }

$projects = getProjects();
$reviews = getReviews();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - SYMPTOM Admin</title>
  <link rel="stylesheet" href="admin-styles.css">
</head>
<body>
  <div class="admin-layout">
    <aside class="sidebar">
      <div class="sidebar-logo">SYMPTOM</div>
      <nav class="sidebar-nav">
        <a href="dashboard.php" class="nav-item active">📊 Dashboard</a>
        <a href="projects.php" class="nav-item">📁 Projets</a>
        <a href="reviews.php" class="nav-item">⭐ Avis</a>
        <a href="logout.php" class="nav-item nav-logout">🚪 Déconnexion</a>
      </nav>
    </aside>
    
    <main class="main-content">
      <header class="content-header">
        <h1>Dashboard</h1>
        <a href="/" target="_blank" class="btn btn-outline">🌐 Voir le site</a>
      </header>
      
      <div class="dashboard-stats">
        <div class="stat-card">
          <div class="stat-icon">📁</div>
          <div class="stat-info">
            <span class="stat-number"><?php echo count($projects); ?></span>
            <span class="stat-label">Projets</span>
          </div>
          <a href="project-edit.php" class="stat-action">+ Ajouter</a>
        </div>
        <div class="stat-card">
          <div class="stat-icon">⭐</div>
          <div class="stat-info">
            <span class="stat-number"><?php echo count($reviews); ?></span>
            <span class="stat-label">Avis</span>
          </div>
          <a href="review-edit.php" class="stat-action">+ Ajouter</a>
        </div>
      </div>
      
      <div class="dashboard-grid">
        <section class="dashboard-section">
          <div class="section-header">
            <h2>📁 Derniers projets</h2>
            <a href="projects.php" class="btn btn-outline btn-sm">Voir tout</a>
          </div>
          <div class="table-container">
            <table class="data-table">
              <thead>
                <tr><th>Entreprise</th><th>Secteur</th><th>Date</th><th></th></tr>
              </thead>
              <tbody>
                <?php 
                $recentProjects = array_slice(array_reverse($projects), 0, 5);
                foreach ($recentProjects as $project): 
                ?>
                <tr>
                  <td><strong><?php echo htmlspecialchars($project['company']); ?></strong></td>
                  <td><span class="badge"><?php echo htmlspecialchars($project['sector']); ?></span></td>
                  <td><?php echo date('d/m/Y', strtotime($project['created_at'])); ?></td>
                  <td><a href="project-edit.php?id=<?php echo $project['id']; ?>" class="btn-icon">✏️</a></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($projects)): ?>
                <tr><td colspan="4" class="empty-state">Aucun projet. <a href="project-edit.php">Créer le premier</a></td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </section>
        
        <section class="dashboard-section">
          <div class="section-header">
            <h2>⭐ Derniers avis</h2>
            <a href="reviews.php" class="btn btn-outline btn-sm">Voir tout</a>
          </div>
          <div class="table-container">
            <table class="data-table">
              <thead>
                <tr><th>Auteur</th><th>Note</th><th>Date</th><th></th></tr>
              </thead>
              <tbody>
                <?php 
                $recentReviews = array_slice(array_reverse($reviews), 0, 5);
                foreach ($recentReviews as $review): 
                ?>
                <tr>
                  <td><strong><?php echo htmlspecialchars($review['author']); ?></strong></td>
                  <td><?php echo str_repeat('⭐', $review['rating']); ?></td>
                  <td><?php echo date('d/m/Y', strtotime($review['created_at'])); ?></td>
                  <td><a href="review-edit.php?id=<?php echo $review['id']; ?>" class="btn-icon">✏️</a></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($reviews)): ?>
                <tr><td colspan="4" class="empty-state">Aucun avis. <a href="review-edit.php">Créer le premier</a></td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </main>
  </div>
</body>
</html>