document.addEventListener('DOMContentLoaded', function() {
  
  // Loader
  var loader = document.getElementById('loader');
  if (loader) {
    setTimeout(function() {
      loader.classList.add('hidden');
    }, 2200);
  }
  
  // Nav scroll
  var nav = document.getElementById('nav');
  window.addEventListener('scroll', function() {
    if (nav) {
      if (window.scrollY > 50) {
        nav.classList.add('scrolled');
      } else {
        nav.classList.remove('scrolled');
      }
    }
  });
  
  // Service card hover effect
  var serviceCards = document.querySelectorAll('.service-card');
  serviceCards.forEach(function(card) {
    card.addEventListener('mousemove', function(e) {
      var rect = card.getBoundingClientRect();
      var x = ((e.clientX - rect.left) / rect.width) * 100;
      var y = ((e.clientY - rect.top) / rect.height) * 100;
      card.style.setProperty('--mouse-x', x + '%');
      card.style.setProperty('--mouse-y', y + '%');
    });
  });
  
  // Reveal text on scroll
  var revealTexts = document.querySelectorAll('.reveal-text');
  var revealObserver = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry, index) {
      if (entry.isIntersecting) {
        setTimeout(function() {
          entry.target.classList.add('visible');
        }, index * 150);
      }
    });
  }, { threshold: 0.3 });
  
  revealTexts.forEach(function(el) {
    revealObserver.observe(el);
  });
  
  // Animate numbers
  var stats = document.querySelectorAll('.stat-number');
  var statsObserver = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        var target = parseInt(entry.target.dataset.target);
        animateNumber(entry.target, target);
        statsObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });
  
  stats.forEach(function(stat) {
    statsObserver.observe(stat);
  });
  
  function animateNumber(el, target) {
    var current = 0;
    var increment = target / 50;
    var timer = setInterval(function() {
      current += increment;
      if (current >= target) {
        el.textContent = target;
        clearInterval(timer);
      } else {
        el.textContent = Math.floor(current);
      }
    }, 40);
  }
  
  // Particles (lightweight)
  var particlesContainer = document.getElementById('hero-particles');
  if (particlesContainer) {
    for (var i = 0; i < 30; i++) {
      var particle = document.createElement('div');
      var size = Math.random() * 3 + 1;
      particle.style.cssText = 
        'position: absolute;' +
        'width: ' + size + 'px;' +
        'height: ' + size + 'px;' +
        'background: rgba(255,255,255,' + (Math.random() * 0.2 + 0.05) + ');' +
        'border-radius: 50%;' +
        'left: ' + (Math.random() * 100) + '%;' +
        'top: ' + (Math.random() * 100) + '%;' +
        'animation: particleFloat ' + (Math.random() * 15 + 10) + 's linear infinite;' +
        'animation-delay: ' + (Math.random() * 5) + 's;';
      particlesContainer.appendChild(particle);
    }
    
    var style = document.createElement('style');
    style.textContent = '@keyframes particleFloat { 0% { transform: translateY(100vh); opacity: 0; } 10% { opacity: 1; } 90% { opacity: 1; } 100% { transform: translateY(-100vh); opacity: 0; } }';
    document.head.appendChild(style);
  }
  
  // Form submission with rocket animation
  var heroForm = document.getElementById('hero-form');
  var contactForm = document.getElementById('contact-form');
  var overlayRocket = document.getElementById('overlay-rocket');
  var redirectUrl = 'https://example.com';
  
  function handleFormSubmit(e) {
    e.preventDefault();
    
    // Add loading state to button
    var submitBtn = e.target.querySelector('.form-btn, .btn-submit');
    if (submitBtn && submitBtn.classList.contains('form-btn')) {
      submitBtn.classList.add('loading');
    }
    
    // Show rocket overlay after short delay
    setTimeout(function() {
      if (overlayRocket) {
        overlayRocket.classList.add('active');
      }
      
      // Redirect after animation
      setTimeout(function() {
        window.location.href = redirectUrl;
      }, 3000);
    }, 500);
  }
  
  if (heroForm) {
    heroForm.addEventListener('submit', handleFormSubmit);
  }
  
  if (contactForm) {
    contactForm.addEventListener('submit', handleFormSubmit);
  }
  
  // Client button
  var clientBtn = document.getElementById('client-btn');
  var clientUrl = 'https://example.com/espace-client';
  
  if (clientBtn) {
    clientBtn.addEventListener('click', function(e) {
      e.preventDefault();
      window.location.href = clientUrl;
    });
  }
  
  // Smooth scroll
  var anchors = document.querySelectorAll('a[href^="#"]');
  anchors.forEach(function(anchor) {
    anchor.addEventListener('click', function(e) {
      var href = this.getAttribute('href');
      if (href === '#') return;
      e.preventDefault();
      var target = document.querySelector(href);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
  
});